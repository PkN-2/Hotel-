import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function AuthPage({ onLogin, onRegister }) {
  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Authentication</CardTitle>
        <CardDescription>Sign in to your account or create a new one.</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="login">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Register</TabsTrigger>
          </TabsList>
          <TabsContent value="login">
            <LoginForm onLogin={onLogin} />
          </TabsContent>
          <TabsContent value="register">
            <RegisterForm onRegister={onRegister} />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

function LoginForm({ onLogin }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [otp, setOtp] = useState('')
  const [showOtpInput, setShowOtpInput] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!showOtpInput) {
      // Request OTP
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/request-otp`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, method: 'email' })
        });
        if (response.ok) {
          setShowOtpInput(true)
        } else {
          alert('Failed to send OTP. Please try again.')
        }
      } catch (error) {
        console.error('Error:', error);
        alert('An error occurred. Please try again.')
      }
    } else {
      // Verify OTP and login
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/verify-otp`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, otp })
        });
        if (response.ok) {
          onLogin(email, password)
        } else {
          alert('Invalid OTP. Please try again.')
        }
      } catch (error) {
        console.error('Error:', error);
        alert('An error occurred. Please try again.')
      }
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <Input
          id="password"
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      {showOtpInput && (
        <div className="space-y-2">
          <Label htmlFor="otp">OTP</Label>
          <Input
            id="otp"
            type="text"
            required
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
          />
        </div>
      )}
      <Button type="submit" className="w-full">
        {showOtpInput ? 'Verify OTP and Login' : 'Request OTP'}
      </Button>
    </form>
  )
}

function RegisterForm({ onRegister }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [otp, setOtp] = useState('')
  const [showOtpInput, setShowOtpInput] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (password !== confirmPassword) {
      alert('Passwords do not match. Please try again.')
      return
    }
    if (!showOtpInput) {
      // Request OTP
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/request-otp`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, method: 'email' })
        });
        if (response.ok) {
          setShowOtpInput(true)
        } else {
          alert('Failed to send OTP. Please try again.')
        }
      } catch (error) {
        console.error('Error:', error);
        alert('An error occurred. Please try again.')
      }
    } else {
      // Verify OTP and register
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/verify-otp`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, otp })
        });
        if (response.ok) {
          onRegister(name, email, password)
        } else {
          alert('Invalid OTP. Please try again.')
        }
      } catch (error) {
        console.error('Error:', error);
        alert('An error occurred. Please try again.')
      }
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Name</Label>
        <Input
          id="name"
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <Input
          id="password"
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="confirmPassword">Confirm Password</Label>
        <Input
          id="confirmPassword"
          type="password"
          required
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
        />
      </div>
      {showOtpInput && (
        <div className="space-y-2">
          <Label htmlFor="otp">OTP</Label>
          <Input
            id="otp"
            type="text"
            required
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
          />
        </div>
      )}
      <Button type="submit" className="w-full">
        {showOtpInput ? 'Verify OTP and Register' : 'Request OTP'}
      </Button>
    </form>
  )
}


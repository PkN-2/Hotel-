import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface Message {
  name: string;
  email: string;
  message: string;
  timestamp: string;
}

export function AdminMessages() {
  const [messages, setMessages] = useState<Message[]>([])

  useEffect(() => {
    const fetchMessages = async () => {
      const response = await fetch('/get-messages');
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
      }
    };

    fetchMessages();
    // Set up polling to check for new messages every 30 seconds
    const interval = setInterval(fetchMessages, 30000);

    return () => clearInterval(interval);
  }, [])

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Admin Messages</CardTitle>
        <CardDescription>View messages from site visitors</CardDescription>
      </CardHeader>
      <CardContent>
        {messages.length === 0 ? (
          <p>No messages yet.</p>
        ) : (
          <ul className="space-y-4">
            {messages.map((msg, index) => (
              <li key={index} className="border-b pb-2">
                <p><strong>From:</strong> {msg.name} ({msg.email})</p>
                <p><strong>Message:</strong> {msg.message}</p>
                <p><strong>Sent at:</strong> {new Date(msg.timestamp).toLocaleString()}</p>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  )
}


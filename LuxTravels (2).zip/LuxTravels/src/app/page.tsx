import Component from './component'
import { FloatingContactButton } from '../components/FloatingContactButton'

export default function Page() {
  return (
    <main className="min-h-screen bg-sky-50">
      <Component />
      <FloatingContactButton />
    </main>
  )
}


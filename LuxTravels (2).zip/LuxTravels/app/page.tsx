import Component from './component'

export default function Page() {
  return (
    <main className="min-h-screen bg-sky-50">
      <Component />
    </main>
  )
}


'use client'
import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Flower, Star, Users, Wifi, Coffee, Utensils, Car, Dumbbell, Waves, Mountain, MapIcon as City, TreePalmIcon as Palm, Castle, Sun, Wine, Ship, CreditCard, Bitcoin, Umbrella, Snowflake, Plane, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react'
import Image from 'next/image'
import { SocialIcon } from './components/SocialIcon'
import { FloatingContactButton } from './components/FloatingContactButton'

export default function Component() {
  const [currentPage, setCurrentPage] = useState('home')
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [selectedHotel, setSelectedHotel] = useState(null)
  const [showPaymentPage, setShowPaymentPage] = useState(false)

  const handleLogin = (email, password) => {
    // In a real application, you would validate credentials here
    setIsAuthenticated(true)
    setCurrentPage('home')
  }

  const handleRegister = (name, email, password) => {
    // In a real application, you would handle registration here
    setIsAuthenticated(true)
    setCurrentPage('home')
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    setSelectedHotel(null)
    setShowPaymentPage(false)
  }

  const handlePageChange = (page) => {
    setCurrentPage(page)
    setSelectedHotel(null)
    setShowPaymentPage(false)
  }

  const handleBookNow = (hotel) => {
    setSelectedHotel(hotel)
    setShowPaymentPage(true)
  }

  return (
    <div className="min-h-screen bg-sky-50 text-sky-900">
      <header className="bg-sky-200 border-b-2 border-amber-300 p-4">
        <nav className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold flex items-center">
            <Flower className="mr-2" />
            Lux Travels
          </h1>
          <ul className="flex space-x-4">
            {['home', 'about', 'contact'].map((page) => (
              <li key={page}>
                <Button
                  variant={currentPage === page ? "secondary" : "ghost"}
                  onClick={() => handlePageChange(page)}
                  className="text-sky-900 hover:text-sky-700"
                >
                  {page.charAt(0).toUpperCase() + page.slice(1)}
                </Button>
              </li>
            ))}
            {isAuthenticated ? (
              <li>
                <Button variant="ghost" onClick={handleLogout} className="text-sky-900 hover:text-sky-700">
                  Logout
                </Button>
              </li>
            ) : (
              <li>
                <Button variant="ghost" onClick={() => handlePageChange('auth')} className="text-sky-900 hover:text-sky-700">
                  Login / Register
                </Button>
              </li>
            )}
          </ul>
        </nav>
      </header>

      <main className="container mx-auto mt-8 p-4">
        {currentPage === 'home' && !showPaymentPage && <HomePage setSelectedHotel={setSelectedHotel} isAuthenticated={isAuthenticated} onBookNow={handleBookNow} />}
        {currentPage === 'about' && <AboutPage />}
        {currentPage === 'contact' && <ContactPage />}
        {currentPage === 'auth' && <AuthPage onLogin={handleLogin} onRegister={handleRegister} />}
        {showPaymentPage && <PaymentPage hotel={selectedHotel} onCancel={() => setShowPaymentPage(false)} />}
      </main>

      <footer className="bg-sky-200 border-t-2 border-amber-300 p-8 mt-8">
        <div className="container mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Lux Travels</h3>
            <p className="text-sm">Your premier luxury travel agency, dedicated to providing unforgettable experiences and seamless reservations for discerning travelers around the world.</p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">Contact Us</h3>
            <p className="text-sm">Email: info@luxtravels.com</p>
            <p className="text-sm">Phone: +1 (555) 123-4567</p>
            <p className="text-sm">Address: 123 Luxury Lane, Opulence City, OC 12345</p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <SocialIcon icon={<Facebook className="w-6 h-6" />} href="https://facebook.com/luxtravels" />
              <SocialIcon icon={<Twitter className="w-6 h-6" />} href="https://twitter.com/luxtravels" />
              <SocialIcon icon={<Instagram className="w-6 h-6" />} href="https://instagram.com/luxtravels" />
              <SocialIcon icon={<Linkedin className="w-6 h-6" />} href="https://linkedin.com/company/luxtravels" />
            </div>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">Newsletter</h3>
            <p className="text-sm mb-2">Subscribe to our newsletter for exclusive deals and travel tips.</p>
            <form className="flex">
              <Input type="email" placeholder="Your email" className="mr-2" />
              <Button type="submit">Subscribe</Button>
            </form>
          </div>
        </div>
        <div className="text-center mt-8">
          <p className="text-sm">&copy; {new Date().getFullYear()} Lux Travels. All rights reserved.</p>
        </div>
      </footer>
      <FloatingContactButton />
    </div>
  )
}

function HomePage({ setSelectedHotel, isAuthenticated, onBookNow }) {
  const hotels = [
    {
      id: 1,
      name: "Saltys on the Creek",
      location: "Waterfront",
      price: 150,
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-DJhsV66MfmOws15XbAxyg20EgQ8bQt.png",
      images: [
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-DJhsV66MfmOws15XbAxyg20EgQ8bQt.png",
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20240830-WA0001.jpg-gvmeI45GRS7UR2yPOKUKLPa4bwSd2t.jpeg",
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20240920-WA0008.jpg-jfU9WCnYngRJo988RL94a4TF9CFN1N.jpeg"
      ],
      amenities: [
        'Unforgettable Dining Experience',
        'Scenic Sunset Views',
        'Creek Swimming',
        'Premium Drinks',
        'Boat Rides'
      ],
      description: "Experience the magic of waterfront dining at Saltys on the Creek. Our floating restaurant offers an unforgettable dining experience with breathtaking sunset views. Enjoy swimming in the crystal-clear creek waters, sip on expertly crafted cocktails and cold beers, or take a relaxing boat ride around the waters. Perfect for both casual outings and special occasions.",
      rating: 4.9,
      reviews: 487,
      features: [
        { icon: <Utensils className="w-5 h-5" />, name: "Premium Dining" },
        { icon: <Sun className="w-5 h-5" />, name: "Sunset Views" },
        { icon: <Waves className="w-5 h-5" />, name: "Swimming" },
        { icon: <Wine className="w-5 h-5" />, name: "Premium Drinks" },
        { icon: <Ship className="w-5 h-5" />, name: "Boat Rides" }
      ],
      icon: <Utensils className="w-6 h-6" />
    },
    {
      id: 2,
      name: "Mountain View Lodge",
      location: "Swiss Alps",
      price: 300,
      image: "/placeholder.svg?height=300&width=400",
      images: [
        "/placeholder.svg?height=600&width=800",
        "/placeholder.svg?height=600&width=800",
        "/placeholder.svg?height=600&width=800"
      ],
      amenities: ['Ski-in/Ski-out', 'Fireplace', 'Hot tub', 'Panoramic views'],
      description: "Nestled in the heart of the Swiss Alps, our lodge offers breathtaking mountain views and direct access to world-class ski slopes. Relax in your private hot tub or cozy up by the fireplace after a day of alpine adventures.",
      rating: 4.7,
      reviews: 352,
      features: [
        { icon: <Wifi className="w-5 h-5" />, name: "Free Wi-Fi" },
        { icon: <Coffee className="w-5 h-5" />, name: "Room Service" },
        { icon: <Utensils className="w-5 h-5" />, name: "Restaurant" },
        { icon: <Car className="w-5 h-5" />, name: "Ski Shuttle" },
        { icon: <Dumbbell className="w-5 h-5" />, name: "Fitness Center" }
      ],
      icon: <Mountain className="w-6 h-6" />
    },
    {
      id: 3,
      name: "City Center Suites",
      location: "New York City",
      price: 400,
      image: "/placeholder.svg?height=300&width=400",
      images: [
        "/placeholder.svg?height=600&width=800",
        "/placeholder.svg?height=600&width=800",
        "/placeholder.svg?height=600&width=800"
      ],
      amenities: ['Rooftop bar', 'Fitness center', 'Business lounge', 'City views'],
      description: "Stay in the heart of the Big Apple with easy access to iconic landmarks, shopping, and entertainment. Our modern suites offer stunning city views, and our rooftop bar is the perfect spot to unwind with a cocktail while overlooking the skyline.",
      rating: 4.6,
      reviews: 623,
      features: [
        { icon: <Wifi className="w-5 h-5" />, name: "Free Wi-Fi" },
        { icon: <Coffee className="w-5 h-5" />, name: "Room Service" },
        { icon: <Utensils className="w-5 h-5" />, name: "Restaurant" },
        { icon: <Car className="w-5 h-5" />, name: "Valet Parking" },
        { icon: <Dumbbell className="w-5 h-5" />, name: "Fitness Center" }
      ],
      icon: <City className="w-6 h-6" />
    },
    {
      id: 4,
      name: "Tropical Paradise Resort",
      location: "Bali",
      price: 350,
      image: "/placeholder.svg?height=300&width=400",
      images: [
        "/placeholder.svg?height=600&width=800",
        "/placeholder.svg?height=600&width=800",
        "/placeholder.svg?height=600&width=800"
      ],
      amenities: ['Private beach', 'Spa', 'Yoga classes', 'Water sports'],
      description: "Escape to our tropical paradise in Bali. Enjoy pristine private beaches, rejuvenating spa treatments, daily yoga classes, and exciting water sports. Immerse yourself in Balinese culture and natural beauty.",
      rating: 4.8,
      reviews: 729,
      features: [
        { icon: <Umbrella className="w-5 h-5" />, name: "Private Beach" },
        { icon: <Waves className="w-5 h-5" />, name: "Water Sports" },
        { icon: <Utensils className="w-5 h-5" />, name: "Beachfront Dining" },
        { icon: <Dumbbell className="w-5 h-5" />, name: "Yoga Studio" },
        { icon: <Coffee className="w-5 h-5" />, name: "Spa Services" }
      ],
      icon: <Palm className="w-6 h-6" />
    },
    {
      id: 5,
      name: "Arctic Igloo Resort",
      location: "Lapland, Finland",
      price: 500,
      image: "/placeholder.svg?height=300&width=400",
      images: [
        "/placeholder.svg?height=600&width=800",
        "/placeholder.svg?height=600&width=800",
        "/placeholder.svg?height=600&width=800"
      ],
      amenities: ['Glass igloos', 'Northern Lights viewing', 'Husky sledding', 'Ice restaurant'],
      description: "Experience the magic of the Arctic in our unique glass igloos. Watch the Northern Lights dance above you, go on thrilling husky sled rides, and dine in our extraordinary ice restaurant. A true winter wonderland adventure awaits.",
      rating: 4.9,
      reviews: 412,
      features: [
        { icon: <Snowflake className="w-5 h-5" />, name: "Glass Igloos" },
        { icon: <Sun className="w-5 h-5" />, name: "Northern Lights Tours" },
        { icon: <Utensils className="w-5 h-5" />, name: "Ice Restaurant" },
        { icon: <Car className="w-5 h-5" />, name: "Husky Sledding" },
        { icon: <Coffee className="w-5 h-5" />, name: "Sauna" }
      ],
      icon: <Snowflake className="w-6 h-6" />
    },
    {
      id: 6,
      name: "Skyline Penthouse",
      location: "Dubai",
      price: 800,
      image: "/placeholder.svg?height=300&width=400",
      images: [
        "/placeholder.svg?height=600&width=800",
        "/placeholder.svg?height=600&width=800",
        "/placeholder.svg?height=600&width=800"
      ],
      amenities: ['360° city views', 'Private chef', 'Infinity pool', 'Helipad access'],
      description: "Indulge in the height of luxury in our exclusive skyline penthouse. Enjoy breathtaking 360° views of Dubai's iconic skyline, personalized service from your private chef, and unparalleled amenities including an infinity pool and helipad access.",
      rating: 4.9,
      reviews: 203,
      features: [
        { icon: <City className="w-5 h-5" />, name: "Panoramic Views" },
        { icon: <Utensils className="w-5 h-5" />, name: "Private Chef" },
        { icon: <Waves className="w-5 h-5" />, name: "Infinity Pool" },
        { icon: <Plane className="w-5 h-5" />, name: "Helipad Access" },
        { icon: <Coffee className="w-5 h-5" />, name: "24/7 Concierge" }
      ],
      icon: <City className="w-6 h-6" />
    }
  ]

  return (
    <div>
      <h2 className="text-3xl font-bold mb-6">Welcome to Lux Travels</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <div className="relative h-[300px] overflow-hidden rounded-lg">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20240920-WA0008.jpg-jfU9WCnYngRJo988RL94a4TF9CFN1N.jpeg"
            alt="Luxurious sunset over water with a boat"
            layout="fill"
            objectFit="cover"
            className="rounded-lg"
          />
          <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
            <h3 className="text-2xl font-bold text-white text-center">Experience Luxury</h3>
          </div>
        </div>
        <div className="relative h-[300px] overflow-hidden rounded-lg">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20240830-WA0001.jpg-gvmeI45GRS7UR2yPOKUKLPa4bwSd2t.jpeg"
            alt="Tropical sunset with flowers"
            layout="fill"
            objectFit="cover"
            className="rounded-lg"
          />
          <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
            <h4 className="text-2xl font-bold text-white text-center">Discover Paradise</h4>
          </div>
        </div>
      </div>
      <div className="bg-amber-100 p-6 rounded-lg flex items-center justify-center mb-12">
        <p className="text-lg text-center">
          At Lux Travels, we curate unforgettable experiences in the world's most breathtaking destinations. 
          From tropical paradises to urban escapes, let us guide you to your perfect getaway.
        </p>
      </div>
      <h3 className="text-2xl font-bold mb-4">Our Featured Destinations</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {hotels.map((hotel) => (
          <HotelCard key={hotel.id} hotel={hotel} onSelect={() => setSelectedHotel(hotel)} isAuthenticated={isAuthenticated} onBookNow={onBookNow} />
        ))}
      </div>
    </div>
  )
}

function HotelCard({ hotel, onSelect, isAuthenticated, onBookNow }) {
  return (
    <Card className="overflow-hidden border-2 border-amber-300">
      <img src={hotel.image} alt={hotel.name} className="w-full h-48 object-cover" />
      <CardHeader>
        <CardTitle className="flex items-center">
          {hotel.icon}
          <span className="ml-2">{hotel.name}</span>
        </CardTitle>
        <CardDescription>{hotel.location}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="font-bold">${hotel.price} per night</p>
        <div className="flex items-center mt-2">
          <Star className="w-5 h-5 text-yellow-400 mr-1" />
          <span className="font-bold mr-2">{hotel.rating}</span>
          <span className="text-gray-600">({hotel.reviews} reviews)</span>
        </div>
        <div className="mt-2">
          <h4 className="font-semibold">Amenities:</h4>
          <ul className="list-disc list-inside">
            {hotel.amenities.slice(0, 3).map((amenity) => (
              <li key={amenity}>{amenity}</li>
            ))}
          </ul>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Dialog>
          <DialogTrigger asChild>
            <Button variant="outline">View</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[700px]">
            <DialogHeader>
              <DialogTitle>{hotel.name}</DialogTitle>
              <DialogDescription>{hotel.location}</DialogDescription>
            </DialogHeader>
            <div className="mt-4">
              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="facilities">Facilities</TabsTrigger>
                  <TabsTrigger value="gallery">Gallery</TabsTrigger>
                </TabsList>
                <TabsContent value="overview">
                  <p className="mb-4">{hotel.description}</p>
                  <div className="flex items-center mb-4">
                    <Star className="w-5 h-5 text-yellow-400 mr-1" />
                    <span className="font-bold mr-2">{hotel.rating}</span>
                    <span className="text-gray-600">({hotel.reviews} reviews)</span>
                  </div>
                  <div className="flex flex-wrap gap-4">
                    {hotel.features.map((feature, index) => (
                      <div key={index} className="flex items-center">
                        {feature.icon}
                        <span className="ml-2">{feature.name}</span>
                      </div>
                    ))}
                  </div>
                </TabsContent>
                <TabsContent value="facilities">
                  <ul className="list-disc list-inside space-y-2">
                    {hotel.amenities.map((amenity, index) => (
                      <li key={index}>{amenity}</li>
                    ))}
                  </ul>
                </TabsContent>
                <TabsContent value="gallery">
                  <div className="grid grid-cols-2 gap-4">
                    {hotel.images.map((image, index) => (
                      <img key={index} src={image} alt={`${hotel.name} - Image ${index + 1}`} className="w-full h-40 object-cover rounded-lg" />
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
              <div className="mt-6">
                <Button className="w-full" onClick={() => onBookNow(hotel)}>Book Now</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
        <Button onClick={() => onBookNow(hotel)}>Book Now</Button>
      </CardFooter>
    </Card>
  )
}

function PaymentPage({ hotel, onCancel }) {
  const [paymentMethod, setPaymentMethod] = useState('credit-card')

  const handlePayment = (e) => {
    e.preventDefault()
    // Here you would typically process the payment
    alert('Payment processed successfully!')
    onCancel() // Return to the main page after payment
  }

  return (
    <div className="max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-4">Payment for {hotel.name}</h2>
      <p className="mb-4">Total amount: ${hotel.price}</p>
      <form onSubmit={handlePayment} className="space-y-4">
        <div>
          <Label>Select Payment Method</Label>
          <div className="grid grid-cols-2 gap-4 mt-2">
            <Button
              type="button"
              variant={paymentMethod === 'credit-card' ? 'default' : 'outline'}
              onClick={() => setPaymentMethod('credit-card')}
              className="flex items-center justify-center"
            >
              <CreditCard className="mr-2" /> Credit Card
            </Button>
            <Button
              type="button"
              variant={paymentMethod === 'paypal' ? 'default' : 'outline'}
              onClick={() => setPaymentMethod('paypal')}
              className="flex items-center justify-center"
            >
              <CreditCard className="mr-2" /> PayPal
            </Button>
            <Button
              type="button"
              variant={paymentMethod === 'crypto' ? 'default' : 'outline'}
              onClick={() => setPaymentMethod('crypto')}
              className="flex items-center justify-center"
            >
              <Bitcoin className="mr-2" /> Crypto
            </Button>
            <Button
              type="button"
              variant={paymentMethod === 'visa' ? 'default' : 'outline'}
              onClick={() => setPaymentMethod('visa')}
              className="flex items-center justify-center"
            >
              <CreditCard className="mr-2" /> Visa
            </Button>
          </div>
        </div>
        {paymentMethod === 'credit-card' && (
          <>
            <div>
              <Label htmlFor="card-number">Card Number</Label>
              <Input id="card-number" placeholder="1234 5678 9012 3456" required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="expiry">Expiry Date</Label>
                <Input id="expiry" placeholder="MM/YY" required />
              </div>
              <div>
                <Label htmlFor="cvv">CVV</Label>
                <Input id="cvv" placeholder="123" required />
              </div>
            </div>
          </>
        )}
        {paymentMethod === 'paypal' && (
          <div>
            <Label htmlFor="paypal-email">PayPal Email</Label>
            <Input id="paypal-email" type="email" placeholder="your@email.com" required />
          </div>
        )}
        {paymentMethod === 'crypto' && (
          <div>
            <Label htmlFor="wallet-address">Wallet Address</Label>
            <Input id="wallet-address" placeholder="Enter your crypto wallet address" required />
          </div>
        )}
        {paymentMethod === 'visa' && (
          <>
            <div>
              <Label htmlFor="visa-number">Visa Card Number</Label>
              <Input id="visa-number" placeholder="4111 1111 1111 1111" required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="visa-expiry">Expiry Date</Label>
                <Input id="visa-expiry" placeholder="MM/YY" required />
              </div>
              <div>
                <Label htmlFor="visa-cvv">CVV</Label>
                <Input id="visa-cvv" placeholder="123" required />
              </div>
            </div>
          </>
        )}
        <div className="flex justify-between">
          <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
          <Button type="submit">Pay Now</Button>
        </div>
      </form>
    </div>
  )
}

function AboutPage() {
  return (
    <div>
      <h2 className="text-3xl font-bold mb-6">About Lux Travels</h2>
      <p className="mb-4">Lux Travels is your premier luxury travel agency, dedicated to providing unforgettable experiences and seamless reservations for discerning travelers around the world.</p>
      <p className="mb-4">With years of experience in the high-end travel industry, our team of experts curates the best destinations, accommodations, and experiences to suit the most refined tastes and preferences.</p>
      <p>Whether you're looking for a luxurious beach getaway, an adventurous mountain retreat, or a cultural city exploration, Lux Travels has got you covered. Let us take care of every exquisite detail while you focus on creating lasting memories in the world's most stunning locations.</p>
    </div>
  )
}

function ContactPage() {
  return (
    <div>
      <h2 className="text-3xl font-bold mb-6">Contact Us</h2>
      <form className="space-y-4">
        <div>
          <Label htmlFor="name">Name</Label>
          <Input id="name" required />
        </div>
        <div>
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" required />
        </div>
        <div>
          <Label htmlFor="message">Message</Label>
          <textarea
            id="message"
            required
            className="w-full min-h-[100px] rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          />
        </div>
        <Button type="submit">Send Message</Button>
      </form>
    </div>
  )
}

function AuthPage({ onLogin, onRegister }) {
  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Authentication</CardTitle>
        <CardDescription>Sign in to your account or create a new one.</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="login">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Register</TabsTrigger>
          </TabsList>
          <TabsContent value="login">
            <LoginForm onLogin={onLogin} />
          </TabsContent>
          <TabsContent value="register">
            <RegisterForm onRegister={onRegister} />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

function LoginForm({ onLogin }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    onLogin(email, password)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <Input
          id="password"
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <Button type="submit" className="w-full">Login</Button>
    </form>
  )
}

function RegisterForm({ onRegister }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    onRegister(name, email, password)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Name</Label>
        <Input
          id="name"
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <Input
          id="password"
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <Button type="submit" className="w-full">Register</Button>
    </form>
  )
}


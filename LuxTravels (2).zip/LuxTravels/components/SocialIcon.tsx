import { ReactNode } from 'react'
import Link from 'next/link'

interface SocialIconProps {
  icon: ReactNode
  href: string
}

export function SocialIcon({ icon, href }: SocialIconProps) {
  return (
    <Link href={href} target="_blank" rel="noopener noreferrer" className="text-sky-900 hover:text-amber-500 transition-colors">
      {icon}
    </Link>
  )
}


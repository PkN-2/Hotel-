import express from 'express';
import crypto from 'crypto';
import nodemailer from 'nodemailer';
import twilio from 'twilio';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(express.json());
app.use(cors());

// In-memory storage for OTPs (in a real application, use a database)
const otpStorage = new Map();

// Function to generate OTP
function generateOTP() {
  return crypto.randomInt(100000, 999999).toString();
}

// Nodemailer transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Twilio client
const twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

// Endpoint to request OTP
app.post('/api/request-otp', (req, res) => {
  const { email, phone, method } = req.body;
  const otp = generateOTP();
  const recipient = method === 'email' ? email : phone;
  otpStorage.set(recipient, otp);

  if (method === 'email') {
    // Send OTP via email
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Your OTP for Lux Travels',
      text: `Your OTP is: ${otp}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.log(error);
        res.status(500).json({ message: 'Failed to send OTP' });
      } else {
        console.log('Email sent: ' + info.response);
        res.status(200).json({ message: 'OTP sent successfully' });
      }
    });
  } else if (method === 'phone') {
    // Send OTP via SMS
    twilioClient.messages
      .create({
        body: `Your Lux Travels OTP is: ${otp}`,
        from: process.env.TWILIO_PHONE_NUMBER,
        to: phone
      })
      .then(() => {
        res.status(200).json({ message: 'OTP sent successfully' });
      })
      .catch((error) => {
        console.error(error);
        res.status(500).json({ message: 'Failed to send OTP' });
      });
  } else {
    res.status(400).json({ message: 'Invalid OTP method' });
  }
});

// Endpoint to verify OTP
app.post('/api/verify-otp', (req, res) => {
  const { email, phone, otp, method } = req.body;
  const recipient = method === 'email' ? email : phone;
  const storedOTP = otpStorage.get(recipient);

  if (storedOTP && storedOTP === otp) {
    otpStorage.delete(recipient); // Remove OTP after successful verification
    res.status(200).json({ message: 'OTP verified successfully' });
  } else {
    res.status(400).json({ message: 'Invalid OTP' });
  }
});

// Endpoint to submit a message
app.post('/api/submit-message', (req, res) => {
  const { name, email, message } = req.body;
  // Here you would typically store the message in a database
  console.log('Received message:', { name, email, message });
  res.status(200).json({ message: 'Message submitted successfully' });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

